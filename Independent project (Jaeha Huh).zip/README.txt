Topic : Machine learning Project (Supervised learning: Predicting the price of a house price)

Author : Jaeha Huh

Program language : Python (Jupyter Notebook App)

Jupyter Notebook libraries that I installed during the project :
- Scikit-learn, Pandas, Numpy, Matplotlib, XGBoost 

